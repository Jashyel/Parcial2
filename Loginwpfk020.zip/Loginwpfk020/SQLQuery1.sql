﻿select * from usarior;
--user, user01
select * from usarios where username = 'user';
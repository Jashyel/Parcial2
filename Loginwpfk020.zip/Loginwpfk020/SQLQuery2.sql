﻿insert into usuarios(username, password, nombre_completo)
values ('administrador', 'nimda', 'administrador');
insert into usuarios(username, password, nombre_completo)
values ('user', 'user01', 'USUARIO');
